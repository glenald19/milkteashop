<?php
// Database credentials
$servername = "localhost"; // Or your database host
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "boba_tea"; // Your database name

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
