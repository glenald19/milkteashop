<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "No product ID provided.";
    exit();
}

$product_id = intval($_GET['id']);

// Get product details to check if an image exists
$query = "SELECT product_image FROM products WHERE product_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

if (!$product) {
    echo "Product not found.";
    exit();
}

// Delete the product image if it exists
if (!empty($product['product_image'])) {
    $image_path = "../images/" . $product['product_image'];
    if (file_exists($image_path)) {
        unlink($image_path); // Delete image file
    }
}

// Delete the product from the database
$delete_query = "DELETE FROM products WHERE product_id = ?";
$stmt = $conn->prepare($delete_query);
$stmt->bind_param("i", $product_id);

if ($stmt->execute()) {
    echo "<script>alert('Product deleted successfully!'); window.location.href='manage_products.php';</script>";
} else {
    echo "Error deleting product: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
