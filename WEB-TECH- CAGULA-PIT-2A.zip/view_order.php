<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php'; // Include database connection

// Fetching the order ID from the URL
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($order_id <= 0) {
    echo "Invalid order ID.";
    exit();
}

// Fetching order details
$query = "SELECT orders.*, users.first_name, users.last_name, users.email, 
                 shipping_addresses.full_name, shipping_addresses.phone, 
                 shipping_addresses.street_address, shipping_addresses.city, 
                 shipping_addresses.state, shipping_addresses.postal_code, 
                 shipping_addresses.country,
                 payments.payment_method, payments.payment_status
          FROM orders
          JOIN users ON orders.user_id = users.user_id
          JOIN shipping_addresses ON orders.address_id = shipping_addresses.address_id
          LEFT JOIN payments ON orders.order_id = payments.order_id
          WHERE orders.order_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Order not found.";
    exit();
}

$order = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Order</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <header>
        <h1>View Order Details</h1>
    </header>

    <main>
        <h2>Order Information</h2>
        <p><strong>Order ID:</strong> <?php echo htmlspecialchars($order['order_id']); ?></p>
        <p><strong>Customer Name:</strong> <?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($order['email']); ?></p>

        <h2>Shipping Address</h2>
        <p><strong>Full Name:</strong> <?php echo htmlspecialchars($order['full_name']); ?></p>
        <p><strong>Phone:</strong> <?php echo htmlspecialchars($order['phone']); ?></p>
        <p><strong>Address:</strong> <?php echo htmlspecialchars($order['street_address'] . ', ' . $order['city'] . ', ' . $order['state'] . ' ' . $order['postal_code'] . ', ' . $order['country']); ?></p>

        <h2>Payment Information</h2>
        <p><strong>Payment Method:</strong> <?php echo htmlspecialchars($order['payment_method']); ?></p>
        <p><strong>Payment Status:</strong> <?php echo htmlspecialchars($order['payment_status']); ?></p>

        <h2>Order Status</h2>
        <p><strong>Status:</strong> <?php echo htmlspecialchars($order['status']); ?></p>

        <a href="admin_orders.php">Back to Orders</a>
    </main>

    <footer>
        <p>&copy; 2025 Milk Tea Shop. All Rights Reserved.</p>
    </footer>
</body>
</html>

<?php
// Close the database connection
mysqli_close($conn);
?>
