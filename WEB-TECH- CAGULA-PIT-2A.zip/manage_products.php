<?php 
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php'; // Ensure correct path to db.php

// Fetching products from the database
$query = "SELECT * FROM products";
$result = $conn->query($query);

// Check for query execution errors
if ($result === false) {
    echo "Error: " . $conn->error;
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <header>
        <h1>Manage Products</h1>
    </header>
    <a href="add_product.php">➕ Add New Product</a><br>
    <a href="admin_dashboard.php">Back Dashbaord</a>


    <main>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Description</th>
                    <th>Stock</th> <!-- New Column -->
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = $result->fetch_assoc()) {
                    $product_id = isset($row['product_id']) ? $row['product_id'] : 'N/A';
                    $product_name = isset($row['product_name']) ? $row['product_name'] : 'No Name';
                    $product_price = isset($row['product_price']) ? $row['product_price'] : '0.00';
                    $description = isset($row['description']) ? $row['description'] : 'No Description';
                    $stock_quantity = isset($row['stock_quantity']) ? $row['stock_quantity'] : 0;
                    $product_image = isset($row['product_image']) ? $row['product_image'] : 'default.png';
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($product_id); ?></td>
                        <td><?php echo htmlspecialchars($product_name); ?></td>
                        <td><?php echo htmlspecialchars($product_price); ?></td>
                        <td><?php echo htmlspecialchars($description); ?></td>
                        <td><?php echo htmlspecialchars($stock_quantity); ?></td> <!-- Stock Display -->
                        <td><img src="../images/<?php echo htmlspecialchars($product_image); ?>" alt="<?php echo htmlspecialchars($product_name); ?>" width="50"></td>
                        <td>
                            <a href="edit_product.php?id=<?php echo $product_id; ?>">Edit</a> | 
                            <a href="delete_product.php?id=<?php echo $product_id; ?>" 
                                onclick="return confirm('Are you sure you want to delete this product? This action cannot be undone.');">
                                🗑 Delete
                            </a>

                        </td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    </main>

    <footer>
        <p>&copy; 2025 Milk Tea Shop. All Rights Reserved.</p>
    </footer>
</body>
</html>

<?php
// Close the database connection
mysqli_close($conn);
?>
