<?php
include 'db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Secure query using prepared statements
    $query = "SELECT user_id, first_name, last_name, password_hash FROM users WHERE email = ? AND role = 'admin'";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();

    // Verify password
    if ($admin && password_verify($password, $admin['password_hash'])) {
        // Regenerate session to prevent session fixation
        session_regenerate_id(true);
        $_SESSION['admin_id'] = $admin['user_id'];
        $_SESSION['admin_name'] = $admin['first_name'] . " " . $admin['last_name'];

        // Redirect to admin dashboard
        header("Location: admin_dashboard.php");
        exit();
    } else {
        $error = "Invalid email or password. Please try again.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <header>
        <h1>Admin Login</h1>
    </header>
    
    <main>
        <form action="admin_login.php" method="POST">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            
            <button type="submit">Login</button>
        </form>
        <?php if (isset($error)) { echo "<p style='color: red;'>$error</p>"; } ?>
        <p>Don't have an account? <a href="admin_register.php">Register here</a></p>
    </main>
    
    <footer>
        <p>&copy; 2025 Milk Tea Shop. All Rights Reserved.</p>
    </footer>
</body>
</html>
