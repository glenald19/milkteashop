<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "No user ID provided.";
    exit();
}

$user_id = intval($_GET['id']);

// Prevent admin from deleting their own account
if ($user_id == $_SESSION['admin_id']) {
    echo "<script>alert('You cannot delete your own account.'); window.location.href='admin_dashboard.php';</script>";
    exit();
}

// Check if user exists
$query = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "<script>alert('User not found.'); window.location.href='admin_dashboard.php';</script>";
    exit();
}

// Delete user
$delete_query = "DELETE FROM users WHERE user_id = ?";
$stmt = $conn->prepare($delete_query);
$stmt->bind_param("i", $user_id);

if ($stmt->execute()) {
    echo "<script>alert('User deleted successfully!'); window.location.href='admin_dashboard.php';</script>";
} else {
    echo "Error deleting user: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
