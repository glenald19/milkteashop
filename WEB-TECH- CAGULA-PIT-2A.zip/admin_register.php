<?php
include 'db.php'; // Ensure this file correctly connects to your database

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $phone = trim($_POST['phone']) ?: NULL; // Optional field
    $role = 'admin'; // Set the role as 'admin'

    // Check if email already exists
    $check_query = "SELECT user_id FROM users WHERE email = ?";
    $stmt = $conn->prepare($check_query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $check_result = $stmt->get_result();

    if ($check_result->num_rows > 0) {
        $error = "Email already exists";
    } else {
        // Insert new admin user
        $query = "INSERT INTO users (first_name, last_name, email, password_hash, phone, role) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssss", $first_name, $last_name, $email, $password, $phone, $role);

        if ($stmt->execute()) {
            $user_id = $stmt->insert_id; // Get the new user's ID

            // Optional: Assign a default shipping address for the admin
            $default_address = "123 Admin Street";
            $default_city = "Admin City";
            $default_state = "Admin State";
            $default_postal = "000000";
            $default_country = "Admin Land";
            $default_phone = $phone ?? '000-000-0000'; // Use provided phone or default

            $address_query = "INSERT INTO shipping_addresses (user_id, full_name, phone, street_address, city, state, postal_code, country) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($address_query);
            $full_name = "$first_name $last_name";
            $stmt->bind_param("isssssss", $user_id, $full_name, $default_phone, $default_address, $default_city, $default_state, $default_postal, $default_country);
            $stmt->execute();

            // Redirect after successful registration
            header("Location: admin_login.php");
            exit();
        } else {
            $error = "Error: " . $stmt->error;
        }
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Register</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <header>
        <h1>Admin Register</h1>
    </header>
    
    <main>
        <form action="admin_register.php" method="POST">
            <input type="text" name="first_name" placeholder="Enter First Name" required>
            <input type="text" name="last_name" placeholder="Enter Last Name" required>
            <input type="email" name="email" placeholder="Enter Email" required>
            <input type="password" name="password" placeholder="Enter Password" required>
            <input type="text" name="phone" placeholder="Enter Phone (Optional)">
            <button type="submit">Register</button>
        </form>
        <?php if (isset($error)) { echo "<p style='color: red;'>$error</p>"; } ?>
    </main>
    
    <footer>
        <p>&copy; 2025 Milk Tea Shop. All Rights Reserved.</p>
    </footer>
</body>
</html>
