<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php'; // Include database connection

// Fetch all orders along with payment details
$query = "SELECT orders.order_id, orders.order_date, orders.total_amount, orders.status, 
                 users.first_name, users.last_name, payments.payment_method 
          FROM orders
          JOIN users ON orders.user_id = users.user_id
          LEFT JOIN payments ON orders.order_id = payments.order_id";

$result = $conn->query($query);

if ($result->num_rows == 0) {
    echo "No orders found.";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <header>
        <h1>Manage Orders</h1>
    </header>

    <main>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Customer Name</th>
                    <th>Order Date</th>
                    <th>Total Amount</th>
                    <th>Status</th>
                    <th>Payment Method</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($order = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($order['order_id']); ?></td>
                    <td><?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?></td>
                    <td><?php echo htmlspecialchars($order['order_date']); ?></td>
                    <td><?php echo htmlspecialchars($order['total_amount']); ?></td>
                    <td><?php echo htmlspecialchars($order['status']); ?></td>
                    <td><?php echo htmlspecialchars($order['payment_method']); ?></td>
                    <td>
                        <a href="view_order.php?id=<?php echo $order['order_id']; ?>">View</a>
                        <a href="update_order.php?id=<?php echo $order['order_id']; ?>">Update Status</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </main>

    <footer>
        <p>&copy; 2025 Milk Tea Shop. All Rights Reserved.</p>
    </footer>
</body>
</html>

<?php
// Close the database connection
mysqli_close($conn);
?>
