<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php'; // Include database connection

// Check if order_id is provided
if (isset($_GET['id'])) {
    $order_id = $_GET['id'];
    
    // Fetch order details
    $query = "SELECT * FROM orders WHERE order_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        echo "Order not found.";
        exit();
    }

    $order = $result->fetch_assoc();

    // Update order status if form is submitted
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['status'])) {
        $status = $_POST['status'];

        // Update the order status in the database
        $update_query = "UPDATE orders SET status = ? WHERE order_id = ?";
        $update_stmt = $conn->prepare($update_query);
        $update_stmt->bind_param("si", $status, $order_id);
        if ($update_stmt->execute()) {
            echo "Order status updated successfully.";
        } else {
            echo "Error updating status.";
        }
    }
} else {
    echo "No order ID provided.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Order</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <header>
        <h1>Update Order Status</h1>
    </header>

    <main>
        <form method="POST">
            <label for="status">Order Status:</label>
            <select name="status" id="status" required>
                <option value="Pending" <?php echo ($order['status'] == 'Pending') ? 'selected' : ''; ?>>Pending</option>
                <option value="Processing" <?php echo ($order['status'] == 'Processing') ? 'selected' : ''; ?>>Processing</option>
                <option value="Shipped" <?php echo ($order['status'] == 'Shipped') ? 'selected' : ''; ?>>Shipped</option>
                <option value="Completed" <?php echo ($order['status'] == 'Completed') ? 'selected' : ''; ?>>Completed</option>
                <option value="Cancelled" <?php echo ($order['status'] == 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
            </select>
            <button type="submit">Update Status</button>
        </form>

        <p><a href="manage_orders.php">Back to Order Management</a></p>
    </main>

    <footer>
        <p>&copy; 2025 Milk Tea Shop. All Rights Reserved.</p>
    </footer>
</body>
</html>

<?php
// Close the database connection
mysqli_close($conn);
?>
