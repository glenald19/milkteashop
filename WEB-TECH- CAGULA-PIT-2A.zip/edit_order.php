<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php';

// Check database connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Securely handle input
    $order_id = $_POST['id'];
    $status = $_POST['status'];

    // Prepare the query with placeholders
    $query = "UPDATE orders SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $status, $order_id);  // "s" for string, "i" for integer

    if ($stmt->execute()) {
        header("Location: admin_orders.php?success=Order updated successfully");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    mysqli_close($conn);
    exit();
} else {
    // Sanitize and validate the GET parameter
    if (isset($_GET['id']) && is_numeric($_GET['id'])) {
        $order_id = $_GET['id'];

        // Secure query to fetch order details
        $query = "SELECT * FROM orders WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $order_id);  // "i" for integer
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $order = $result->fetch_assoc();
        } else {
            echo "Order not found.";
            exit();
        }

        $stmt->close();
    } else {
        echo "Invalid order ID.";
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Order</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <header>
        <h1>Edit Order</h1>
    </header>
    
    <main>
        <form action="edit_order.php" method="POST">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($order['id']); ?>">
            
            <label for="status">Status:</label>
            <select id="status" name="status" required>
                <option value="Pending" <?php if ($order['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                <option value="Completed" <?php if ($order['status'] == 'Completed') echo 'selected'; ?>>Completed</option>
                <option value="Cancelled" <?php if ($order['status'] == 'Cancelled') echo 'selected'; ?>>Cancelled</option>
            </select>
            
            <button type="submit">Update</button>
        </form>
    </main>
    
    <footer>
        <p>&copy; 2025 Milk Tea Shop. All Rights Reserved.</p>
    </footer>
</body>
</html>
