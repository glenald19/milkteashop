<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = trim($_POST['product_name']);
    $product_price = floatval($_POST['product_price']);
    $description = trim($_POST['description']);
    $stock_quantity = intval($_POST['stock_quantity']);
    $product_image = null;

    // Handle image upload if file is provided
    if (!empty($_FILES['product_image']['name'])) {
        $image_name = basename($_FILES['product_image']['name']);
        $target_dir = "../images/";
        $target_file = $target_dir . $image_name;

        if (move_uploaded_file($_FILES['product_image']['tmp_name'], $target_file)) {
            $product_image = $image_name;
        }
    }

    // Insert query
    $query = "INSERT INTO products (product_name, product_price, description, stock_quantity, product_image) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sdsis", $product_name, $product_price, $description, $stock_quantity, $product_image);

    if ($stmt->execute()) {
        echo "<script>alert('Product added successfully!'); window.location.href='manage_products.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Product</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <header>
        <h1>Add New Product</h1>
    </header>

    <main>
        <form action="" method="post" enctype="multipart/form-data">
            <label for="product_name">Name:</label>
            <input type="text" name="product_name" id="product_name" required>

            <label for="product_price">Price:</label>
            <input type="number" step="0.01" name="product_price" id="product_price" required>

            <label for="description">Description:</label>
            <textarea name="description" id="description" required></textarea>

            <label for="stock_quantity">Stock Quantity:</label>
            <input type="number" name="stock_quantity" id="stock_quantity" required>

            <label for="product_image">Product Image:</label>
            <input type="file" name="product_image" id="product_image">

            <br><br>
            <button type="submit">Add Product</button>
            <a href="manage_products.php">Cancel</a>
        </form>
    </main>

    <footer>
        <p>&copy; 2025 Milk Tea Shop. All Rights Reserved.</p>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
