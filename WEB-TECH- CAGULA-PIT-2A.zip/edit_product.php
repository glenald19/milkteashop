<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php';

if (!isset($_GET['id'])) {
    echo "No product ID provided.";
    exit();
}

$product_id = intval($_GET['id']);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = trim($_POST['product_name']);
    $product_price = floatval($_POST['product_price']);
    $description = trim($_POST['description']);
    $stock_quantity = intval($_POST['stock_quantity']);
    $product_image = null;

    // Handle image upload if a file is provided
    if (!empty($_FILES['product_image']['name'])) {
        $image_name = basename($_FILES['product_image']['name']);
        $target_dir = "../images/";
        $target_file = $target_dir . $image_name;

        if (move_uploaded_file($_FILES['product_image']['tmp_name'], $target_file)) {
            $product_image = $image_name;
        }
    }

    // Prepare update query
    $update_query = "UPDATE products SET 
                        product_name = ?, 
                        product_price = ?, 
                        description = ?, 
                        stock_quantity = ?" .
                        ($product_image ? ", product_image = ?" : "") . 
                    " WHERE product_id = ?";

    $stmt = $conn->prepare($update_query);

    if ($product_image) {
        $stmt->bind_param("sdsssi", $product_name, $product_price, $description, $stock_quantity, $product_image, $product_id);
    } else {
        $stmt->bind_param("sdssi", $product_name, $product_price, $description, $stock_quantity, $product_id);
    }

    if ($stmt->execute()) {
        echo "<script>alert('Product updated successfully!'); window.location.href='manage_products.php';</script>";
    } else {
        echo "Error updating product: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch current product details
$query = "SELECT * FROM products WHERE product_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

if (!$product) {
    echo "Product not found.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Product</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <header>
        <h1>Edit Product</h1>
    </header>

    <main>
        <form action="" method="post" enctype="multipart/form-data">
            <label for="product_name">Name:</label>
            <input type="text" name="product_name" id="product_name" value="<?php echo htmlspecialchars($product['product_name']); ?>" required>

            <label for="product_price">Price:</label>
            <input type="number" step="0.01" name="product_price" id="product_price" value="<?php echo htmlspecialchars($product['product_price']); ?>" required>

            <label for="description">Description:</label>
            <textarea name="description" id="description" required><?php echo htmlspecialchars($product['description']); ?></textarea>

            <label for="stock_quantity">Stock Quantity:</label>
            <input type="number" name="stock_quantity" id="stock_quantity" value="<?php echo htmlspecialchars($product['stock_quantity']); ?>" required>

            <label for="product_image">Image:</label>
            <input type="file" name="product_image" id="product_image">
            <?php if ($product['product_image']) : ?>
                <br><img src="../images/<?php echo htmlspecialchars($product['product_image']); ?>" alt="Product Image" width="100">
            <?php endif; ?>

            <br><br>
            <button type="submit">Update Product</button>
            <a href="manage_products.php">Cancel</a>
        </form>
    </main>

    <footer>
        <p>&copy; 2025 Milk Tea Shop. All Rights Reserved.</p>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
